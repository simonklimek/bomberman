<h1> BomberMan Game </h1>
This is a game of BomberMan coded in Scheme. It has five levels. Difficulty increases on going to higher levels.

<h4> Implementation details can be found <a href="http://shivamh71.github.io/Bomberman.pdf">here</a></h4>

<h4> Requirements </h4>
	drracket needs to installed

<h4> Instructions </h4>
	1. Go to the folder named 'code'.
	2. Open drracket and select the language as PrettyBig.
	3. Open the file named 'start.scm' in drracket.
	4. Press 'Ctrl + R' to run.
	5. We have password protected higher levels having passwords as below:
		level 1 : No password required
		level 2: 'level2'
		level 3: 'level3'
		level 4: 'level4'
		level 5: 'level5'
