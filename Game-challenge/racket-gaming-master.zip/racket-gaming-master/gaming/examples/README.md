Racket Gaming Examples Directory
================================

This directory contains some examples showing off the features that Racket gaming has to offer.
At the same time, these examples are useful for getting to know how the library works and how it is used.

## Overview

### Ball Pool

Just some balls in a ceiled-off space bouncing against one another.
