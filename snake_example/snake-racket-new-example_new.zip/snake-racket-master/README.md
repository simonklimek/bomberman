snake-racket
============

Snake game in Racket derived from the tetris-racket code

Special thanks go to Vanderson M. do Rosario for "carrying" me.
