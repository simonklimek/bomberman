# autosnake
A self-playing snake game.

After creating a simple Snake game for a final project, I was challenged by a friend to make the computer (somewhat)
intelligently make decisions in the game itself rather than following keyboard input. This game represents my first effort
at attacking this problem.
